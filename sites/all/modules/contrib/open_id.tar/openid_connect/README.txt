The OpenID Connect module provides a pluggable client implementation for the
OpenID Connect protocol.

For more information please consult the documentation: https://drupal.org/node/2274339
